-- NeoTelegramChat 2.1 HOURLY GUI (NeoMLoader / Arizona New Engine)
-- Separate from ConnectTools. Mirrors server chat received by THIS client.
-- Does not capture passwords, dialog input, or outgoing commands.
-- Telegram HTTPS: Copas + LuaSec (peer verification and bundled CA roots).
-- It does NOT modify any game packets, chat messages, or reconnection behavior.

if type(script_name) == 'function' then script_name('NeoTelegramChat') end
if type(script_author) == 'function' then script_author('OpenAI / NeoMLoader') end
if type(script_version) == 'function' then script_version('2.1 GUI') end

local SCRIPT_DIR = './'
do
    if debug and debug.getinfo then
        local src = debug.getinfo(1, 'S').source
        if type(src) == 'string' and src:sub(1, 1) == '@' then
            SCRIPT_DIR = src:sub(2):match('^(.*[/\\])') or './'
        end
    end
end
local CONFIG_PATH = SCRIPT_DIR .. 'NeoTelegramChat_config.json'
local JOURNAL_PATH = SCRIPT_DIR .. 'NeoTelegramChat_hourly_journal.jsonl'
local CURSOR_PATH = SCRIPT_DIR .. 'NeoTelegramChat_hourly_cursor.txt'
local CA_PATH = SCRIPT_DIR .. 'NeoTelegramChat_CA.pem'
local PREFIX = '[NeoTG] '

local function note(msg)
    print(PREFIX .. tostring(msg))
end
local function chat(msg)
    if type(sampAddChatMessage) == 'function' then
        pcall(sampAddChatMessage, PREFIX .. tostring(msg), 0xFFB84D)
    end
    note(msg)
end

local function safe_require(mod)
    local ok, value = pcall(require, mod)
    if ok then return value end
    note('Module unavailable: ' .. mod)
    return nil
end

local json = safe_require('cjson')
local event = safe_require('samp.events')
local copas = safe_require('copas')
local http = copas and safe_require('copas.http') or nil
local ltn12 = safe_require('ltn12')
local socket = safe_require('socket')
local ffi = safe_require('ffi')
local imgui = safe_require('mimgui')
local encoding = safe_require('encoding')
if encoding then encoding.default = 'CP1251' end

-- Settings are edited through /tgmenu; JSON is an internal persistence format only.
-- Existing NeoTelegramChat_config.json (v1/v2) is read automatically.
local defaults = {
    bot_token = '',
    admin_chat_id = '',
    enabled = true,
    include_outgoing_chat = false,
    max_journal_mb = 64,
    send_interval_seconds = 1.25,
    include_time = true
}
local function read_config()
    local file = io.open(CONFIG_PATH, 'rb')
    if not file then return {} end
    local raw = file:read('*a') or ''
    file:close()
    if not json then return {} end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= 'table' then
        note('Existing settings invalid; settings window can replace them.')
        return {}
    end
    return data
end
local cfg = read_config()
for k,v in pairs(defaults) do if cfg[k] == nil then cfg[k] = v end end
if cfg.bot_token == 'PUT_BOT_TOKEN_HERE' then cfg.bot_token = '' end
if cfg.admin_chat_id == 'PUT_YOUR_CHAT_ID_HERE' then cfg.admin_chat_id = '' end

local TOKEN, CHAT_ID = '', ''
local configured, network_ready = false, false
local ca_ok = false
local network_failed = false
local network_libs = not not (event and copas and http and ltn12 and json and socket)
do
    local f = io.open(CA_PATH, 'rb')
    if f then ca_ok = true; f:close() end
end
local function refresh_network_state()
    TOKEN = tostring(cfg.bot_token or '')
    CHAT_ID = tostring(cfg.admin_chat_id or '')
    configured = TOKEN:match('^%d+:[%w_%-]+$') ~= nil and CHAT_ID:match('^%-?%d+$') ~= nil
    network_ready = configured and ca_ok and network_libs and not network_failed
    return network_ready
end
refresh_network_state()
if not configured then note('Open /tgmenu to enter Telegram credentials.') end
if not ca_ok then note('CA bundle missing: NeoTelegramChat_CA.pem.') end

local function save_cfg()
    if not json then return false, 'cjson missing' end
    local ok, encoded=pcall(json.encode, cfg)
    if not ok then return false, 'JSON encode failed' end
    local tmp=CONFIG_PATH .. '.tmp'
    local f=io.open(tmp,'wb')
    if not f then return false, 'Cannot write settings' end
    local wrote=f:write(encoded)
    f:flush()
    f:close()
    if not wrote then return false, 'Settings write failed' end
    if not os.rename(tmp,CONFIG_PATH) then
        os.remove(tmp)
        return false, 'Cannot replace saved settings'
    end
    refresh_network_state()
    return true
end

-- Convert legacy CP1251 only if the incoming text is NOT valid UTF-8.
local function valid_utf8(s)
    local i,n = 1,#s
    while i<=n do
        local c=s:byte(i)
        if c < 128 then i=i+1
        else
            local count
            if c>=194 and c<=223 then count=2
            elseif c>=224 and c<=239 then count=3
            elseif c>=240 and c<=244 then count=4
            else return false end
            if i+count-1>n then return false end
            local c2=s:byte(i+1)
            if c2<128 or c2>191 or (c==224 and c2<160) or (c==237 and c2>159)
                or (c==240 and c2<144) or (c==244 and c2>143) then return false end
            for j=i+2,i+count-1 do local b=s:byte(j); if b<128 or b>191 then return false end end
            i=i+count
        end
    end
    return true
end
local specials = {
    [0x80]=0x0402,[0x81]=0x0403,[0x82]=0x201A,[0x83]=0x0453,[0x84]=0x201E,
    [0x85]=0x2026,[0x86]=0x2020,[0x87]=0x2021,[0x88]=0x20AC,[0x89]=0x2030,
    [0x8A]=0x0409,[0x8B]=0x2039,[0x8C]=0x040A,[0x8D]=0x040C,[0x8E]=0x040B,
    [0x8F]=0x040F,[0x90]=0x0452,[0x91]=0x2018,[0x92]=0x2019,[0x93]=0x201C,
    [0x94]=0x201D,[0x95]=0x2022,[0x96]=0x2013,[0x97]=0x2014,[0x99]=0x2122,
    [0x9A]=0x0459,[0x9B]=0x203A,[0x9C]=0x045A,[0x9D]=0x045C,[0x9E]=0x045B,
    [0x9F]=0x045F,[0xA0]=0x00A0,[0xA1]=0x040E,[0xA2]=0x045E,[0xA3]=0x0408,
    [0xA4]=0x00A4,[0xA5]=0x0490,[0xA6]=0x00A6,[0xA7]=0x00A7,[0xA8]=0x0401,
    [0xA9]=0x00A9,[0xAA]=0x0404,[0xAB]=0x00AB,[0xAC]=0x00AC,[0xAD]=0x00AD,
    [0xAE]=0x00AE,[0xAF]=0x0407,[0xB0]=0x00B0,[0xB1]=0x00B1,[0xB2]=0x0406,
    [0xB3]=0x0456,[0xB4]=0x0491,[0xB5]=0x00B5,[0xB6]=0x00B6,[0xB7]=0x00B7,
    [0xB8]=0x0451,[0xB9]=0x2116,[0xBA]=0x0454,[0xBB]=0x00BB,[0xBC]=0x0458,
    [0xBD]=0x0405,[0xBE]=0x0455,[0xBF]=0x0457,
}
local function codepoint_to_utf8(n)
    if n<128 then return string.char(n) end
    if n<2048 then return string.char(192+math.floor(n/64),128+n%64) end
    if n<65536 then return string.char(224+math.floor(n/4096),128+math.floor(n/64)%64,128+n%64) end
    return string.char(240+math.floor(n/262144),128+math.floor(n/4096)%64,128+math.floor(n/64)%64,128+n%64)
end
local function to_utf8(s)
    s=tostring(s or '')
    if valid_utf8(s) then return s end
    if encoding and encoding.UTF8 then
        local ok, encoded=pcall(function() return encoding.UTF8(s) end)
        if ok and type(encoded)=='string' and valid_utf8(encoded) then return encoded end
    end
    local out={}
    for i=1,#s do
        local b=s:byte(i)
        local cp=b<128 and b or (b>=0xC0 and (0x0410+b-0xC0) or specials[b])
        out[#out+1]=codepoint_to_utf8(cp or 0xFFFD)
    end
    return table.concat(out)
end
local function clean_text(s)
    s=to_utf8(s)
    s=s:gsub('%b{}',function(chunk)
        if chunk:match('^{%x%x%x%x%x%x}$') or chunk:match('^{%x%x%x%x%x%x%x%x}$') then return '' end
        return chunk
    end)
    s=s:gsub('[\r\n]+',' / '):gsub('%z','')
    return s
end

-- HOURLY MODE: local-phone time HH:00..HH:59, send after next HH:00.
-- Append-only journal survives a game restart at 04:50. Never writes token to log.
 -- Telegram accepts up to 4096 characters; 3200 UTF-8 BYTES is a conservative cap.
local MAX_PAYLOAD_BYTES = 3200
local MAX_LINE_BYTES = 2200
local BUFFER_CAP = 800
local JOURNAL_CAP = math.max(8, math.min(tonumber(cfg.max_journal_mb) or 64, 256)) * 1024 * 1024
local send_interval = math.max(1, math.min(tonumber(cfg.send_interval_seconds) or 1.25, 10))
local paused, received, saved, sent, parts, dropped, bad_records = false, 0, 0, 0, 0, 0, 0
local last_error, last_success = 'none', 'never'
local last_warn_at = 0
local next_attempt = 0
local test_queued = 0
local rows = {}
local ack_pos, read_pos = 0, 0
local function now() return (socket and socket.gettime and socket.gettime()) or os.time() end
local function file_size()
    local f = io.open(JOURNAL_PATH, 'rb')
    if not f then return 0 end
    local size = f:seek('end') or 0
    f:close()
    return size
end
local function atomic_cursor(pos)
    local f = io.open(CURSOR_PATH .. '.tmp', 'wb')
    if not f then return false end
    f:write(tostring(pos), '\n')
    f:close()
    if os.rename(CURSOR_PATH .. '.tmp', CURSOR_PATH) then return true end
    return false
end
local function load_cursor()
    local f = io.open(CURSOR_PATH,'rb')
    if f then
        ack_pos = math.max(0, math.floor(tonumber(f:read('*l')) or 0))
        f:close()
    end
    local sz = file_size()
    if ack_pos > sz then
        note('Journal was reset externally; starting from byte 0.')
        ack_pos = 0
        atomic_cursor(0)
    end
    read_pos = ack_pos
end
load_cursor()
local journal_bytes = file_size()
local function warn_storage(reason)
    dropped = dropped + 1
    last_error = 'journal: ' .. reason
    if now()-last_warn_at > 60 then
        last_warn_at = now()
        chat('Hourly journal unavailable (' .. reason .. '). Some chat lines cannot be saved.')
    end
end
local function append_record(hour, line)
    local item = json.encode({h=hour, text=line}) .. '\n'
    if journal_bytes + #item > JOURNAL_CAP then
        warn_storage('full')
        return false
    end
    local f = io.open(JOURNAL_PATH, 'ab')
    if not f then warn_storage('write failed'); return false end
    local ok = f:write(item)
    f:flush()
    f:close()
    if not ok then warn_storage('write failed'); return false end
    journal_bytes = journal_bytes + #item
    saved = saved + 1
    return true
end
local function utf8_cut(s, limit)
    local part = s:sub(1,limit)
    while #part>0 and not valid_utf8(part) do part=part:sub(1,-2) end
    return part
end
local function collect(source, message)
    if not cfg.enabled or paused or not configured or not json then return end
    local body = clean_text(message)
    if body == '' then return end
    -- The script never forwards slash commands, logins, dialog input or passwords typed by player.
    if source == 'OUT' and body:match('^%s*/') then return end
    local line = (cfg.include_time and (os.date('%H:%M:%S') .. ' ') or '')
       .. (source=='OUT' and '[ME] ' or '') .. body
    local hour = os.date('%Y%m%d%H')
    received = received + 1
    while #line > MAX_LINE_BYTES do
        local part = utf8_cut(line, MAX_LINE_BYTES)
        if #part==0 then break end
        append_record(hour, part)
        line = '[continued] ' .. line:sub(#part+1)
    end
    if #line>0 then append_record(hour, line) end
end
if event then
    event.onServerMessage = function(color, message)
        collect('IN', message)
        -- Don't modify the original game chat.
    end
    event.onSendChat = function(message)
        if cfg.include_outgoing_chat then collect('OUT', message) end
    end
end

-- Read only a bounded number of records at once, so huge chat histories don't fill RAM.
local function refill()
    if #rows >= BUFFER_CAP then return end
    local f = io.open(JOURNAL_PATH,'rb')
    if not f then return end
    local sz = f:seek('end') or 0
    if read_pos > sz then read_pos = sz end
    f:seek('set',read_pos)
    while #rows < BUFFER_CAP do
        local raw = f:read('*l')
        if not raw then break end
        local end_pos = f:seek() or read_pos
        if end_pos <= read_pos then break end
        local ok, record = pcall(json.decode, raw)
        if ok and type(record)=='table' and type(record.h)=='string'
           and record.h:match('^%d%d%d%d%d%d%d%d%d%d$') and type(record.text)=='string' then
            rows[#rows+1] = {h=record.h,text=record.text,ending=end_pos}
        else
            bad_records = bad_records+1
            -- An invalid stored line is represented as a skip marker, preserving cursor ordering.
            rows[#rows+1] = {skip=true, ending=end_pos}
        end
        read_pos = end_pos
    end
    f:close()
end
local function advance_cursor(n)
    if n < 1 then return false end
    local upto = rows[n] and rows[n].ending
    if not upto then return false end
    if not atomic_cursor(upto) then
        last_error = 'cursor write failed; deliveries may repeat'
        note(last_error)
        return false
    end
    ack_pos = upto
    for _=1,n do table.remove(rows,1) end
    return true
end

local function maybe_compact()
    -- Compact only after every persisted row has been acknowledged.
    if #rows~=0 or ack_pos < 2*1024*1024 or read_pos ~= ack_pos then return end
    local f = io.open(JOURNAL_PATH,'rb')
    if not f then return end
    local sz = f:seek('end') or 0
    f:close()
    if sz ~= ack_pos then return end
    local w = io.open(JOURNAL_PATH,'wb')
    if not w then return end
    w:close()
    ack_pos, read_pos, journal_bytes = 0, 0, 0
    atomic_cursor(0)
    note('Hourly journal compacted after delivery.')
end
local function header_for(hour)
    local yyyy,mo,dd,hh = hour:sub(1,4), hour:sub(5,6), hour:sub(7,8), hour:sub(9,10)
    return '📜 Arizona Online · Yuma\n' .. 'Чат за ' .. dd .. '.' .. mo .. '.' .. yyyy
        .. ' · ' .. hh .. ':00–' .. hh .. ':59 (время телефона)\n\n'
end
local function build_hourly_payload()
    local first = rows[1]
    if not first or first.skip then return nil,0 end
    -- Never send current hour automatically. Old hours can be sent after restarting Arizona.
    if first.h >= os.date('%Y%m%d%H') then return nil,0 end
    local heading = header_for(first.h)
    local result = {heading}
    local bytes = #heading
    local n = 0
    for i=1,#rows do
        local item = rows[i]
        if item.skip or item.h~=first.h then break end
        if bytes+#item.text+1>MAX_PAYLOAD_BYTES then break end
        n=n+1
        result[#result+1]=item.text
        bytes=bytes+#item.text+1
    end
    if n==0 then return nil,0 end
    return table.concat(result,'\n'), n
end
local function try_send(payload)
    local body = json.encode({chat_id=CHAT_ID,text=payload,link_preview_options={is_disabled=true}})
    local out = {}
    local ok, ret, status = pcall(http.request, {
        url='https://api.telegram.org/bot' .. TOKEN .. '/sendMessage',
        method='POST',
        source=ltn12.source.string(body),
        sink=ltn12.sink.table(out),
        headers={['content-type']='application/json; charset=utf-8', ['content-length']=tostring(#body)},
        timeout={connect=10,send=10,receive=15},
        redirect=false,
        sslparams={
            wrap={protocol='any',options='all',verify='peer',cafile=CA_PATH},
            sni={strict=true}
        }
    })
    if not ok or not ret then return false,0,10 end
    status = tonumber(status) or 0
    local decoded
    pcall(function() decoded=json.decode(table.concat(out)) end)
    if status==200 and decoded and decoded.ok==true then return true,200,0 end
    local retry = 10
    if status==429 then
        retry=math.min(math.max(tonumber(decoded and decoded.parameters and decoded.parameters.retry_after) or 20,2),180)
    elseif status==400 or status==401 or status==403 then
        retry=60
    end
    return false,status,retry
end
if network_libs then
    copas.addthread(function()
        local next_read = 0
        while true do
            local t = now()
            if t >= next_read then
                refill()
                next_read = t + 2
            end
            if network_ready and cfg.enabled and t >= next_attempt then
                if test_queued>0 then
                    local ok,status,delay = try_send('✅ NeoTelegramChat HOURLY TEST · ' .. os.date('%Y-%m-%d %H:%M:%S'))
                    if ok then
                        test_queued = test_queued-1
                        last_success=os.date('%H:%M:%S')
                        last_error='none'
                        next_attempt=now()+send_interval
                    else
                        last_error='test HTTP ' .. tostring(status)
                        if status==400 or status==401 or status==403 then
                            test_queued=0 -- Permanent test error must not block hourly reports.
                        end
                        next_attempt=now()+delay
                    end
                elseif rows[1] and rows[1].skip then
                    -- Skip invalid stored row without blocking valid later hours.
                    if advance_cursor(1) then next_attempt=now()+0.1 else next_attempt=now()+60 end
                else
                    local payload,n=build_hourly_payload()
                    if payload and n>0 then
                        local ok,status,delay=try_send(payload)
                        if ok then
                            if advance_cursor(n) then
                                sent=sent+n
                                parts=parts+1
                                last_success=os.date('%H:%M:%S')
                                last_error='none'
                                maybe_compact()
                                next_attempt=now()+send_interval
                            else
                                next_attempt=now()+60
                            end
                        else
                            last_error='hourly HTTP ' .. tostring(status) .. ' or network error'
                            next_attempt=now()+delay
                            note(last_error .. '; retry scheduled')
                        end
                    end
                end
            end
            copas.sleep(0.2)
        end
    end)
end

local function status_line()
    local hour = os.date('%H:00–%H:59')
    return string.format('HOURLY %s | ready=%s | saved=%d | sent=%d | parts=%d | buffer=%d | journalKB=%d | dropped=%d | test=%d | last=%s | err=%s',
        hour,tostring(not not network_ready),saved,sent,parts,#rows,math.floor(journal_bytes/1024),dropped,test_queued,last_success,last_error)
end
-- NeoMLoader's mimgui implementation is the same API used by ConnectTools.
-- The window may be reopened with /tgmenu or /ntg, with no file editing.
local window_open, token_buf, chatid_buf, enabled_ptr, outgoing_ptr, time_ptr
local ui_ready = false
local ui_message = 'Введи данные, нажми «Сохранить», затем «Тест». '
local function new_cbuf(value, cap)
    local b=ffi.new('char[?]',cap)
    local value_str=tostring(value or '')
    ffi.copy(b,value_str,math.min(cap-1,#value_str))
    return b
end
local function sync_ui_from_settings()
    if not ui_ready then return end
    ffi.fill(token_buf, ffi.sizeof(token_buf), 0)
    ffi.fill(chatid_buf, ffi.sizeof(chatid_buf), 0)
    local token=tostring(cfg.bot_token or '')
    local id=tostring(cfg.admin_chat_id or '')
    ffi.copy(token_buf, token, math.min(#token,ffi.sizeof(token_buf)-1))
    ffi.copy(chatid_buf, id, math.min(#id,ffi.sizeof(chatid_buf)-1))
    enabled_ptr[0]=not not cfg.enabled
    outgoing_ptr[0]=not not cfg.include_outgoing_chat
    time_ptr[0]=not not cfg.include_time
end
local function validate_form()
    local token=ffi.string(token_buf):gsub('^%s+',''):gsub('%s+$','')
    local id=ffi.string(chatid_buf):gsub('^%s+',''):gsub('%s+$','')
    if not token:match('^%d+:[%w_%-]+$') then
        return nil, nil, 'Токен неправильного формата. Открой BotFather.'
    end
    if not id:match('^%-?%d+$') then
        return nil, nil, 'Chat ID должен состоять из цифр.'
    end
    return token,id
end
local function save_from_form()
    if not ui_ready then return false end
    local token,id,err=validate_form()
    if not token then ui_message=err; return false end
    local before={
        bot_token=cfg.bot_token, admin_chat_id=cfg.admin_chat_id,
        enabled=cfg.enabled, include_outgoing_chat=cfg.include_outgoing_chat,
        include_time=cfg.include_time
    }
    cfg.bot_token=token
    cfg.admin_chat_id=id
    cfg.enabled=enabled_ptr[0]
    cfg.include_outgoing_chat=outgoing_ptr[0]
    cfg.include_time=time_ptr[0]
    local ok,why=save_cfg()
    if not ok then
        for k,v in pairs(before) do cfg[k]=v end
        refresh_network_state()
        ui_message='Ошибка сохранения: ' .. tostring(why)
        return false
    end
    next_attempt=0 -- Saved credentials take effect immediately, even after a previous HTTP backoff.
    ui_message=network_ready and 'Сохранено! Можно проверить отправку.'
                              or 'Сохранено, но сеть недоступна: проверь сертификат и библиотеки.'
    return true
end
local function queue_test()
    if network_ready and cfg.enabled then
        test_queued=test_queued+1
        next_attempt=0
        ui_message='Тест поставлен в очередь. Результат смотри в статусе.'
        chat('Telegram test queued.')
    else
        ui_message='Нет подключения: проверь токен/ID, включение и CA.'
        chat('Telegram not ready; see /tgmenu.')
    end
end
local function ui_init()
    if not (imgui and imgui.new and imgui.OnFrame and ffi) then
        note('mimgui or ffi missing: /tgmenu unavailable.')
        return false
    end
    window_open=imgui.new.bool(false)
    token_buf=new_cbuf(cfg.bot_token,256)
    chatid_buf=new_cbuf(cfg.admin_chat_id,64)
    enabled_ptr=imgui.new.bool(not not cfg.enabled)
    outgoing_ptr=imgui.new.bool(not not cfg.include_outgoing_chat)
    time_ptr=imgui.new.bool(not not cfg.include_time)
    ui_ready=true

    if type(imgui.OnInitialize)=='function' then
        imgui.OnInitialize(function()
            pcall(function()
                local style=imgui.GetStyle()
                style.WindowRounding=10
                style.FrameRounding=7
                style.WindowPadding=imgui.ImVec2(13,12)
                if imgui.Col and imgui.Col.Button then
                    style.Colors[imgui.Col.Button]=imgui.ImVec4(.11,.34,.53,1)
                    style.Colors[imgui.Col.ButtonHovered]=imgui.ImVec4(.15,.46,.69,1)
                    style.Colors[imgui.Col.ButtonActive]=imgui.ImVec4(.13,.28,.42,1)
                end
            end)
        end)
    end

    local function draw()
        if not window_open[0] then return end
        if type(imgui.SetNextWindowSize)=='function' then
            imgui.SetNextWindowSize(imgui.ImVec2(620,450),imgui.Cond.FirstUseEver)
        end
        imgui.Begin('NeoTelegramChat 2.1 | Yuma', window_open)
        imgui.Text('ARIZONA ONLINE  /  Telegram Chat Monitor')
        imgui.Separator()
        if imgui.BeginTabBar('NeoTGSettings') then
            if imgui.BeginTabItem('Подключение') then
                imgui.TextWrapped('Настройка через меню. Файлы вручную редактировать не нужно.')
                imgui.Text('Bot Token')
                local flags=(imgui.InputTextFlags and imgui.InputTextFlags.Password) or 0
                imgui.InputText('##NeoTGBotToken',token_buf,ffi.sizeof(token_buf),flags)
                imgui.Text('Telegram Chat ID')
                imgui.InputText('##NeoTGChatId',chatid_buf,ffi.sizeof(chatid_buf),0)
                imgui.Separator()
                if imgui.Button('Сохранить и применить') then save_from_form() end
                imgui.SameLine()
                if imgui.Button('Сохранить + тест') then
                    if save_from_form() then queue_test() end
                end
                imgui.TextWrapped(ui_message)
                imgui.TextWrapped('Боту сначала нужно написать /start. Токен не показывается в логах и чате, но сохраняется в локальных настройках без шифрования.')
                imgui.EndTabItem()
            end
            if imgui.BeginTabItem('Отчёты') then
                imgui.TextWrapped('Режим: один отчёт за каждый час HH:00–HH:59. Отправка после начала следующего часа.')
                imgui.Checkbox('Включить запись и отправку',enabled_ptr)
                imgui.Checkbox('Добавлять время к строкам',time_ptr)
                imgui.Checkbox('Добавлять мой обычный чат (НЕ команды)',outgoing_ptr)
                imgui.TextWrapped('Чат сохраняется на диск: перезапуск Arizona в 04:50 не должен стирать накопленное.')
                imgui.TextWrapped('При большом потоке отчёт делится на несколько частей для Telegram.')
                if imgui.Button('Сохранить параметры') then save_from_form() end
                if imgui.Button(paused and 'Возобновить сбор' or 'Пауза сбора') then
                    paused=not paused
                end
                imgui.EndTabItem()
            end
            if imgui.BeginTabItem('Диагностика') then
                imgui.Text('Bot token / Chat ID: ' .. (configured and 'OK' or 'NOT SET'))
                imgui.Text('HTTPS certificate: ' .. (ca_ok and 'OK' or 'MISSING'))
                imgui.Text('Network libraries: ' .. (network_libs and 'OK' or 'MISSING'))
                imgui.Text('Sender: ' .. (network_ready and 'READY' or 'NOT READY'))
                imgui.TextWrapped(status_line())
                if imgui.Button('Отправить тест') then
                    if save_from_form() then queue_test() end
                end
                imgui.TextWrapped('Telegram HTTP-ошибки: 401 = неверный токен, 403 = бот заблокирован, 400 = проверь Chat ID.')
                imgui.EndTabItem()
            end
            imgui.EndTabBar()
        end
        imgui.Separator()
        if imgui.Button('Закрыть меню') then window_open[0]=false end
        imgui.End()
    end
    imgui.OnFrame(function() return window_open[0] end, function()
        local ok,err=pcall(draw)
        if not ok then
            window_open[0]=false
            ui_message='Ошибка mimgui: '..tostring(err)
            note(ui_message)
        end
    end)
    return true
end
ui_init()

local function open_menu()
    if ui_ready and window_open then
        if not window_open[0] then sync_ui_from_settings() end
        window_open[0]=not window_open[0]
    else
        chat('mimgui unavailable. Check neomloader.log.')
    end
end

local registered=false
local function register_commands()
    if registered or type(sampRegisterChatCommand)~='function' then return end
    sampRegisterChatCommand('tgmenu',open_menu)
    sampRegisterChatCommand('ntg',open_menu)
    sampRegisterChatCommand('tgtest',queue_test)
    sampRegisterChatCommand('tgstat', function() chat(status_line()) end)
    sampRegisterChatCommand('tgpause', function() paused=true; chat('Capture paused; saved lines remain queued.') end)
    sampRegisterChatCommand('tgresume', function() paused=false; chat('Capture resumed.') end)
    registered=true
end
function main()
    if not event then chat('Missing samp.events: chat capturing disabled.') end
    if not ui_ready then chat('mimgui unavailable. See neomloader.log.') end
    if not network_ready then chat('Open /tgmenu to configure Telegram.') end
    note('HOURLY GUI: local time; capture to disk, deliver after each hour; /tgmenu for settings.')
    while true do
        if not registered then
            local available=true
            if type(isSampAvailable)=='function' then
                local ok,res=pcall(isSampAvailable)
                available=ok and res
            end
            if available then register_commands() end
        end
        if network_libs and not network_failed then
            local ok=pcall(copas.step,0)
            if not ok then
                note('Copas failed; sender stopped (token hidden).')
                network_failed=true
                refresh_network_state()
            end
        end
        wait(50)
    end
end
