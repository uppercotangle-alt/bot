NeoTelegramChat v2.1 GUI / NeoMLoader / Arizona Engine 2.0
=========================================================

What changed:
- In-game mimgui setup window: /tgmenu or /ntg.
- Paste BotFather token and numeric Telegram chat ID, press "Сохранить + тест".
- The sender becomes active immediately after Save; no script reload required.
- Existing settings NeoTelegramChat_config.json from v1.1/v2.0 are loaded automatically.
- Hourly reports remain: local time HH:00–HH:59, send after next HH:00.
- Journal and delivery cursor survive the Arizona restart at 04:50.
- Outgoing chat capture is off by default; slash commands are never forwarded.

Installation:
1. BACK UP these files on your Redmi 4X if present:
   NeoTelegramChat_config.json, NeoTelegramChat_hourly_journal.jsonl,
   NeoTelegramChat_hourly_cursor.txt.
2. Remove old Lua versions of NeoTelegramChat from the NeoMLoader script directory.
   Do NOT remove the above three saved data files.
3. Copy NeoTelegramChat.lua and NeoTelegramChat_CA.pem next to each other
   into the same script directory you used for the previous NeoTelegramChat.
4. Launch/reload script, enter /tgmenu in the game chat.
5. In the Connection tab, enter Telegram bot token & numeric chat ID.
   Send /start to your bot in Telegram first.
6. Click "Сохранить + тест" to save and test. Test message is immediate.
   Check "Диагностика" for status, errors and saved lines.

Commands:
 /tgmenu    open/close mimgui setup
 /ntg       alias
 /tgtest    send immediate Telegram test
 /tgstat    show status
 /tgpause   temporarily pause capturing lines
 /tgresume  resume capturing lines

Important:
- The settings screen replaces MANUAL JSON EDITING; under the hood the bot
  token is stored locally (UNENCRYPTED) to survive restarts. Do not share this
  file or post it publicly. The token is masked in the UI.
- Only lines the server delivers to YOUR client can be logged.
- Telegram bots cannot read your private DMs unless they are messages to the
  bot; this script only sends the in-game lines you receive to your bot.
- Hourly mode sends after the hour changes, not once each minute.
- Long hours are split into multiple Telegram messages, respecting byte caps.
- If you installed v2.0, its existing journal and cursor are kept.
- HTTPS requires the bundled NeoTelegramChat_CA.pem. Do not delete it.
- This build passed syntax validation and a mock of mimgui/settings/capture,
  but has not yet been tested inside your actual NeoMLoader build.
